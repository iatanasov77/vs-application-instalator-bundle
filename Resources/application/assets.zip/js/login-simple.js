const $ = require( 'jquery' );
global.$ = $;
window.$ = $;

require( '@popperjs/core/dist/umd/popper.js' );
require( 'bootstrap' );

require( './application-login-page/main-simple.js' );

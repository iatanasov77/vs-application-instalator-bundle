const $ = require( 'jquery' );
global.$ = $;
window.$ = $;

require( '@popperjs/core/dist/umd/popper.js' );
require( 'bootstrap' );

require( '../vendor/application-login-page/js/main.js' );

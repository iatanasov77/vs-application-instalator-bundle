const $ = require( 'jquery' );
global.$ = $;
window.$ = $;

require( 'bootstrap' );

/* Require Global Application Scripts */


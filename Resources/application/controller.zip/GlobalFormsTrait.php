<?php namespace App\Controller\__application_name__;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\User\UserInterface;

trait GlobalFormsTrait
{
    protected function _getAppUser():? UserInterface
    {
        if ( $this->container->has( 'vs_users.security_bridge' ) ) {
            return $this->container->get( 'vs_users.security_bridge' )->getUser();
        }

        return $this->getUser();
    }
    
    protected function _getDoctrine()
    {
        if ( \method_exists( $this, 'getDoctrine' ) ) {
            return $this->getDoctrine();
        } else {
            return $this->doctrine;
        }
    }
}

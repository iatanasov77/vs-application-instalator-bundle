const $ = require( 'jquery' );
global.$ = $;
window.$ = $;

require( '../../vendor/application-login-page/animsition/js/animsition.min.js' );

require( '@popperjs/core/dist/umd/popper.js' );
require( 'bootstrap' );

require( '../../vendor/application-login-page/select2/select2.min.js' );
require( '../../vendor/application-login-page/countdowntime/countdowntime.js' );

require( './application-login-page/main.js' );

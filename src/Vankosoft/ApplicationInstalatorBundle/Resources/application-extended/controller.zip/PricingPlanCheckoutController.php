<?php namespace App\Controller\__application_name__;

use Vankosoft\PaymentBundle\Controller\PricingPlans\PricingPlanCheckoutController as BasePricingPlanCheckoutController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class PricingPlanCheckoutController extends BasePricingPlanCheckoutController
{
	use GlobalFormsTrait;
	
    public function showPricingPlans( Request $request ): Response
    {
        $pricingPlanCategories  = $this->pricingPlanCategoryRepository->findAll();
        
        return $this->render( '@VSPayment/Pages/PricingPlansCheckout/pricing_plans.html.twig', [
            'pricingPlanCategories' => $pricingPlanCategories,
			'subscriptions'         => $this->subscriptionsRepository->getSubscriptionsByUser( $this->securityBridge->getUser() )
			'shoppingCart'          => $this->getShoppingCart( $request ),
        ]);
    }
}
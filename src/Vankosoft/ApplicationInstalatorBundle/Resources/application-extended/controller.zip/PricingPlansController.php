<?php namespace App\Controller\__application_name__;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Sylius\Component\Resource\Repository\RepositoryInterface;

class PricingPlansController extends AbstractController
{
    /** @var RepositoryInterface */
    private $pricingPlanCategoryRepository;
    
    public function __construct(
        RepositoryInterface $pricingPlanCategoryRepository
    ) {
        $this->pricingPlanCategoryRepository    = $pricingPlanCategoryRepository;
    }
    
    public function index( Request $request ): Response
    {
        $pricingPlanCategories  = $this->pricingPlanCategoryRepository->findAll();
        
        return $this->render( 'Pages/pricing_plans.html.twig', [
            'pricingPlanCategories' => $pricingPlanCategories,
        ]);
    }
}